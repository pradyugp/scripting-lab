mydictionary =	{
  "name": "Archie",
  "identity": "Student",
  "age": 17
}
print(mydictionary)

key = mydictionary["name"]
value = mydictionary.get("name")
print("Key is", key)
print("Value is", value)
