import dictionary 
print "Calling Atomic Dictionary" 

dictionary.atomicdictionary()





